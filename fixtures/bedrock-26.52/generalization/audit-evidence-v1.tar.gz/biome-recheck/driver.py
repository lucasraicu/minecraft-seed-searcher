"""Frozen stable-API copied-world recheck of four new biome discrepancies."""
import argparse
import fcntl
import hashlib
import json
from pathlib import Path
import re
import sys
import time

ROOT = Path('/Users/lucasraicu/Downloads/minecraft-seed-searcher')
BASE = Path(__file__).resolve().parent
sys.path[:0] = [str(BASE),str(ROOT / 'scripts')]
from targeted_bds_budgeted import run_world, IMAGE
from predictor_storage_probe import tree_hashes


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def atomic(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def execute(enabled=False):
    raw = (BASE / 'biome-recheck-v2.json').read_bytes()
    if digest(raw) != (BASE / 'biome-recheck-v2.sha256').read_text().strip():
        raise ValueError('Biorecheck manifest changed')
    value = json.loads(raw)
    parent_raw = (BASE / 'manifest.json').read_bytes()
    parent = json.loads(parent_raw)
    if value['parent_manifest_sha256'] != digest(parent_raw):
        raise ValueError('Original manifest differs')
    cases = value['cases']
    if len(cases) != 2 or [c['dimension'] for c in cases] != ['overworld', 'nether']:
        raise ValueError('Recheck scope differs')
    for case in cases:
        if case['index'] != 20 or case['seed'] != parent['worlds'][20]['seed'] or case['structures'] or case['columns']:
            raise ValueError('Case identity/scope differs')
        if not 1 <= len(case['points']) <= 64 or len(case['points']) != len({tuple(p) for p in case['points']}):
            raise ValueError('Point cap/duplicates')
        for p in case['points']:
            if (len(p) != 3 or any(type(v) is not int for v in p) or max(abs(p[0]),abs(p[2])) > 5120 or
                not (0 if case['dimension'] == 'nether' else -64) <= p[1] <= (127 if case['dimension'] == 'nether' else 319)):
                raise ValueError('Invalid XYZ')
        if len({(p[0]//16,p[2]//16) for p in case['points']}) > 10:
            raise ValueError('Chunk cap')
        observer = Path(case['observer'])
        source = Path(case['source_world'])
        if observer.parent != BASE or digest(observer.read_bytes()) != case['observer_sha256']:
            raise ValueError('Observer changed')
        if source.is_symlink() or not source.is_relative_to(BASE/'game') or source.resolve() != source:
            raise ValueError('Source outside owned stopped campaign')
        if tree_hashes(source) != case['source_world_hashes']:
            raise ValueError('Source world changed')
    if sum(len(c['points']) for c in cases) != 46:
        raise ValueError('Frozen read count differs')
    if not enabled:
        return dict(dry_run=True, copies=2, points=46, beta_enabled=False, locates=0, volume_reads=0)
    out = BASE/'biome-recheck-output'
    with (BASE/'game/campaign.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        original = json.loads((BASE/'game/ledger.json').read_bytes())
        membership_summary=json.loads((BASE/'membership-summary.json').read_bytes())
        membership=membership_summary['attempts']
        if len(original) != 24 or any(r['state'] != 'complete' for r in original):
            raise ValueError('Original campaign unfinished')
        if membership_summary['completed_cases']!=5 or any(r['state']=='starting' for r in membership):
            raise ValueError('Prior copied-world phase unfinished')
        if out.exists():
            raise ValueError('Already attempted; no automatic retries')
        out.mkdir()
        (out/'frozen.json').write_bytes(raw)
        (out/'driver.py').write_bytes(Path(__file__).read_bytes())
        ledger = []
        atomic(out/'ledger.json', ledger)
        for case in cases:
            previous = next(r['wall_seconds'] for r in original if r['index'] == 20)
            previous += sum(r['wall_seconds'] for r in membership + ledger if r['index'] == 20)
            total = sum(r['wall_seconds'] for r in original + membership + ledger)
            wall = min(120, int(min(600-previous,7200-total))-120)
            row = dict(index=20, seed=case['seed'], dimension=case['dimension'],
                       state='unattempted_budget' if wall < 30 else 'starting', wall_seconds=0.)
            ledger.append(row)
            atomic(out/'ledger.json', ledger)
            if wall < 30:
                continue
            if sum(p.stat().st_size for p in BASE.rglob('*') if p.is_file() and not p.is_symlink()) > 8 << 30:
                raise OSError('Owned output cap')
            started = time.monotonic()
            directory = out/case['dimension']
            try:
                report = run_world(case,directory,wall,'docker',digest(raw),out,
                    observer_path=case['observer'],copied_world=case['source_world'],script_api='2.10.0')
                row['report_sha256'] = digest((directory/'report.json').read_bytes())
                row['source_unchanged'] = tree_hashes(Path(case['source_world'])) == case['source_world_hashes']
                identity = report.get('world_identity',{})
                console = (directory/'console.log').read_text()
                ok = (report['status']=='observed' and row['source_unchanged'] and
                    all(report.get(k) is True for k in ('clean_shutdown','owned_container_removed','save_confirmed')) and
                    identity.get('dimension') == case['dimension'] and
                    re.search(r'\bVersion: 1\.26\.52\.3(?:\s|$)',console) is not None)
                row.update(state='complete' if ok else 'failed',error=report.get('error'))
            except Exception as error:
                row.update(state='failed',error=type(error).__name__+': '+str(error))
            finally:
                row['wall_seconds'] = time.monotonic()-started
                row['seed_cumulative_seconds'] = previous+row['wall_seconds']
                row['campaign_cumulative_seconds'] = total+row['wall_seconds']
                atomic(out/'ledger.json',ledger)
            print(json.dumps(row),flush=True)
            if row['state']!='complete' or row['seed_cumulative_seconds']>600 or row['campaign_cumulative_seconds']>7200:
                raise RuntimeError('Failed/budget exhausted; no new dispatch')
    return dict(copies=len(ledger),status='terminal',ledger=str(out/'ledger.json'))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute',action='store_true')
    args=parser.parse_args()
    print(json.dumps(execute(enabled=args.execute)),flush=True)
