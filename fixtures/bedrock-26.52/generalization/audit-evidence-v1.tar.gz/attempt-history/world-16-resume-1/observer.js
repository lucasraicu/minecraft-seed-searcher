// Read-only, bounded biome observations in an owned disposable world.
import { world, system } from '@minecraft/server';
let busy = false, biomeReads = 0, blockReads = 0;
const tick = () => new Promise(resolve => system.run(resolve));
world.afterEvents.worldLoad.subscribe(() => console.warn('GENERALIZATION_IDENTITY ' + JSON.stringify({
  seed: world.seed, api: '2.10.0', players: world.getAllPlayers().length,
  membershipAvailable: typeof world.getDimension('overworld').getGeneratedStructures === 'function',
})));
system.afterEvents.scriptEventReceive.subscribe(async event => {
  if (event.id !== 'generalization:observe') return;
  let q;
  try {
    if (busy) throw Error('Concurrent request');
    busy = true; q = JSON.parse(event.message);
    if (!Number.isInteger(q.id) || !['overworld', 'nether', 'the_end'].includes(q.dimension) ||
        !Array.isArray(q.points) || q.points.length < 1 || q.points.length > 12) throw Error('Invalid batch');
    const dim = world.getDimension(q.dimension), manager = world.tickingAreaManager;
    const rows = [], chunks = new Map();
    for (const p of q.points) {
      if (!Array.isArray(p) || p.length !== 3 || !p.every(Number.isInteger) ||
          Math.abs(p[0]) > 5120 || Math.abs(p[2]) > 5120 ||
          p[1] < (q.dimension === 'overworld' ? -64 : 0) ||
          p[1] > (q.dimension === 'nether' ? 127 : (q.dimension === 'the_end' ? 255 : 319))) throw Error('Invalid XYZ');
      const key = Math.floor(p[0] / 16) + ',' + Math.floor(p[2] / 16);
      if (!chunks.has(key)) chunks.set(key, []);
      chunks.get(key).push(p);
    }
    const found = new Map();
    for (const points of chunks.values()) {
      manager.removeAllTickingAreas();
      const [x, , z] = points[0];
      const opts = {dimension: dim, from: {x, y: 63, z}, to: {x, y: 63, z}};
      if (!manager.hasCapacity(opts)) throw Error('Ticking-area capacity');
      await manager.createTickingArea('generalization_' + q.id, opts);
      await tick();
      for (const [px, py, pz] of points) {
        const row = {x: px, y: py, z: pz, dimension: q.dimension};
        if (++biomeReads > 1024 || ++blockReads > 8192) throw Error('Cumulative read cap');
        try {
          const block = dim.getBlock({x: px, y: py, z: pz});
          if (!block) throw Error('Block unavailable');
          row.id = dim.getBiome({x: px, y: py, z: pz}).id;
          row.block = block.typeId;
        } catch (error) { row.error = String(error); }
        found.set([px, py, pz].join(','), row);
        await tick();
      }
    }
    for (const p of q.points) rows.push(found.get(p.join(',')));
    manager.removeAllTickingAreas();
    console.warn('GENERALIZATION_RESULT ' + JSON.stringify({id: q.id, dimension: q.dimension,
      rows, biomeReads, blockReads, chunksAfterUnload: manager.chunkCount}));
  } catch (error) {
    try { world.tickingAreaManager.removeAllTickingAreas(); } catch (_) {}
    console.warn('GENERALIZATION_ERROR ' + JSON.stringify({id: q?.id, error: String(error), biomeReads, blockReads}));
  } finally { busy = false; }
});
