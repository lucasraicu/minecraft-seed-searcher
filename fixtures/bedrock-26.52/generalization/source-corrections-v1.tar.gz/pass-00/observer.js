// Targeted, read-only membership on a disposable already-saved world copy.
import {world, system} from '@minecraft/server';
const DIMENSION = 'nether';
const tick = () => new Promise(resolve => system.run(resolve));
let busy = false;
world.afterEvents.worldLoad.subscribe(() => console.warn('TARGET_IDENTITY ' + JSON.stringify({
  seed: world.seed, api: '2.10.0', players: world.getAllPlayers().length,
  dimension: DIMENSION,
  membershipAvailable: typeof world.getDimension(DIMENSION).getGeneratedStructures === 'function',
})));
system.afterEvents.scriptEventReceive.subscribe(async event => {
  if (event.id !== 'predictor_audit:observe') return;
  if (busy) { console.warn('TARGET_ERROR duplicate request'); return; }
  busy = true;
  let biomeReads = 0, blockReads = 0, membershipReads = 0;
  const dim = world.getDimension(DIMENSION), manager = world.tickingAreaManager;
  try {
    const q = JSON.parse(event.message);
    if (!Array.isArray(q.points) || !Array.isArray(q.columns) || q.columns.length ||
        q.points.length < 1 || q.points.length > 64) throw Error('Input cap');
    const chunks = new Map();
    for (const p of q.points) {
      if (!Array.isArray(p) || p.length !== 3 || !p.every(Number.isInteger) ||
          Math.max(Math.abs(p[0]), Math.abs(p[2])) > 5120 ||
          p[1] < (DIMENSION === 'nether' ? 0 : -64) ||
          p[1] > (DIMENSION === 'nether' ? 127 : 319)) throw Error('Invalid XYZ');
      chunks.set(Math.floor(p[0] / 16) + ',' + Math.floor(p[2] / 16), p);
    }
    if (chunks.size > 10) throw Error('Ticking-area cap');
    let index = 0;
    const loaded = [];
    for (const p of chunks.values()) {
      const [x,y,z] = p;
      let available = false;
      try { available = !!dim.getBlock({x,y,z}); blockReads++; } catch (_) { blockReads++; }
      if (!available) {
        const options = {dimension: dim, from: {x,y,z}, to: {x,y,z}};
        if (!manager.hasCapacity(options)) throw Error('Ticking-area capacity');
        let ready = false, failure;
        manager.createTickingArea('generalization_member_' + index++, options)
          .then(() => { ready = true; }).catch(error => { failure = error; });
        for (let n = 0; !ready && !failure && n < 400; n++) await tick();
        if (failure) throw failure;
        if (!ready) throw Error('Bounded chunk loading did not complete');
      }
      if (++blockReads > 8192 || !dim.getBlock({x,y,z})) throw Error('Chunk unavailable');
      loaded.push({x,y,z});
    }
    const rows = [];
    for (const [x,y,z] of q.points) {
      try {
        if (++biomeReads > 128 || ++blockReads > 8192) throw Error('Read cap');
        const id = dim.getBiome({x,y,z}).id;
        const block = dim.getBlock({x,y,z});
        if (!block) throw Error('Block unavailable');
        rows.push({x,y,z,dimension:DIMENSION,id,block:block.typeId});
      } catch (error) { rows.push({x,y,z,dimension:DIMENSION,error:String(error)}); }
      await tick();
    }
    // Hold owned areas through the caller's save and clean shutdown, on this copy only.
    console.warn('TARGET_RESULT ' + JSON.stringify({rows,columns:[],loaded,
      biomeReads,blockReads,membershipReads,tickingAreas:index,chunks:manager.chunkCount,
      interpretation:'Default-API biome recheck on fresh diagnostic world; no block mutations or census'}));
  } catch (error) {
    console.warn('TARGET_ERROR ' + JSON.stringify({error:String(error),biomeReads,blockReads,membershipReads}));
  }
});
