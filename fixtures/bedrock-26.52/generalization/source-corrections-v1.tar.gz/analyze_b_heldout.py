from pathlib import Path
import json,re,collections
P=Path(__file__).parent;f=json.loads((P/'b-heldout-frozen.json').read_text());alias=json.loads((P.parent/'generalization-validation-20261020/manifest.json').read_text())['aliases']
def canonical(v):v=v.removeprefix('minecraft:');return alias.get(v,v)
stats=collections.Counter();bad=[];structures=[]
for i,c in enumerate(f['cases']):
 r=json.loads((P/f'b-heldout-game/pass-{i:02}/report.json').read_text())
 assert r['status']=='observed' and r['save_confirmed'] and r['clean_shutdown'] and r['owned_container_removed']
 if c['dimension']=='nether':
  for p,o in zip(c['prediction']['selector'],r['target_result']['rows'],strict=True):
   actual=canonical(o['id']);assert p['point']==[o['x'],o['y'],o['z']]
   stats['points']+=1;stats['old_matches']+=p['old']==actual;stats['new_matches']+=p['new']==actual
   stats[p['role']+'_points']+=1;stats[p['role']+'_matches']+=p['new']==actual
   if p['new']!=actual:bad.append(dict(seed=c['seed'],prediction=p,actual=actual))
 for q,o in zip(c['structures'],r['queries'],strict=True):
  text=' '.join(o['output']);m=re.search(r'at block (-?\d+),\s*\(y\?\),\s*(-?\d+)',text)
  assert m,text
  located=[int(m[1]),int(m[2])]
  structures.append(dict(seed=c['seed'],dimension=c['dimension'],query=q,located=located,exact=located==q['point'],raw_output=text))
result=dict(revision='source-diagnostic-heldout-v1',stats=dict(stats),mismatches=bad,structures=structures,game_starts=8,seconds=json.loads((P/'b-heldout-game/ledger.json').read_text())[-1]['total_seconds'],interpretation='New source diagnostic controls, not population accuracy or production implementation')
(P/'b-heldout-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(stats=stats,mismatches=len(bad),exact_queries=sum(r['exact']for r in structures),restored_exact=[dict(seed=r['seed'],feature=r['query']['feature'],point=r['query']['point'])for r in structures if r['exact']and r['query'].get('old')==0 and r['query'].get('new')==1])))
