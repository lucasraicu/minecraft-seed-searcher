"""Execute only frozen source-diagnostic controls; default dry run, no predictor edits."""
import argparse,fcntl,hashlib,json,re,subprocess,sys,time
from pathlib import Path
P=Path(__file__).parent;ROOT=Path('/Users/lucasraicu/Downloads/minecraft-seed-searcher')
sys.path[:0]=[str(P),str(ROOT/'scripts')]
from b_targeted_runner import run_world,IMAGE,owned_size

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def atomic(p,v):t=p.with_suffix('.tmp');t.write_text(json.dumps(v,indent=2)+'\n');t.replace(p)
def run(execute=False):
 raw=(P/'b-heldout-frozen.json').read_bytes();f=json.loads(raw)
 if hashlib.sha256(raw).hexdigest()!=(P/'b-heldout-frozen.sha256').read_text().strip():raise ValueError('Manifest changed')
 expected=['8467329634092353248','8467328534580725472','-3239846069929595036','-3239846065634627740']
 assert f['seeds']==expected and len(f['cases'])==8
 for name,digest in f['hashes'].items():assert sha(P/name)==digest
 for i,c in enumerate(f['cases']):
  assert c['seed']==expected[i//2] and c['dimension']==('nether' if i%2==0 else 'overworld')
  assert c['columns']==[] and 1<=len(c['points'])<=25 and len(c['structures'])<=5
  assert len({tuple(p) for p in c['points']})==len(c['points'])
  assert len({(p[0]//16,p[2]//16) for p in c['points']})<=10
  for x,y,z in c['points']:
   assert all(type(n) is int for n in (x,y,z)) and max(abs(x),abs(z))<=2048
   assert (0 if c['dimension']=='nether' else -64)<=y<=(127 if c['dimension']=='nether' else 319)
  for q in c['structures']:
   assert (q['feature'],q['command_id']) in [('structure.bastion','bastion_remnant'),('structure.fortress','fortress'),('structure.ancient_city','ancient_city')]
   assert (q['feature']=='structure.ancient_city')==(c['dimension']=='overworld')
   assert len(q['point'])==2 and all(type(n)is int and abs(n)<=2048 for n in q['point'])
 if not execute:return dict(dry_run=True,starts=8,points=sum(len(c['points'])for c in f['cases']),locates=sum(len(c['structures'])for c in f['cases']),caps=f['limits'])
 out=P/'b-heldout-game'
 with (P.parent/'generalization-validation-20261020/game/campaign.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  assert not subprocess.check_output(['docker','ps','-q'],text=True,timeout=5).strip(),'Another container is running; do not overlap or terminate it'
  assert subprocess.check_output(['docker','image','inspect',IMAGE,'--format','{{.Id}}'],text=True,timeout=5).strip()==IMAGE
  out.mkdir(exist_ok=False)
  frozen_files=['run_b_heldout.py','b_targeted_runner.py','b-observer-nether.js','b-observer-overworld.js','b-heldout-frozen.json']
  atomic(out/'controls.json',dict(hashes={n:sha(P/n)for n in frozen_files},caps=f['limits'],world_policy='fresh default settings stable2.10; no beta/copy/membership/volume; source diagnostic only'))
  start=time.monotonic();ledger=[]
  for i,c in enumerate(f['cases']):
   if time.monotonic()-start>1045 or owned_size(out)>1<<30:raise TimeoutError('Total campaign cap/headroom')
   if i%2 and sum(r['wall_seconds']for r in ledger if r['seed']==c['seed'])>145:raise TimeoutError('Per-seed headroom')
   row=dict(index=i,seed=c['seed'],dimension=c['dimension'],state='starting',wall_seconds=0)
   ledger.append(row);atomic(out/'ledger.json',ledger);t=time.monotonic()
   try:
    report=run_world(c,out/f'pass-{i:02}',140,'docker',hashlib.sha256(raw).hexdigest(),out,observer_path=P/f'b-observer-{c["dimension"]}.js')
    identity=report.get('world_identity',{})
    ok=(report['status']=='observed' and all(report.get(k)is True for k in ('clean_shutdown','owned_container_removed','save_confirmed')) and identity.get('dimension')==c['dimension'] and identity.get('seed')==c['seed'] and identity.get('api')=='2.10.0' and re.search(r'\bVersion: 1\.26\.52\.3(?:\s|$)',(out/f'pass-{i:02}/console.log').read_text()))
    row.update(state='complete' if ok else 'failed',error=report.get('error'),report_sha256=sha(out/f'pass-{i:02}/report.json'))
   except Exception as e:row.update(state='failed',error=repr(e))
   finally:
    row['wall_seconds']=time.monotonic()-t;row['total_seconds']=time.monotonic()-start;atomic(out/'ledger.json',ledger)
   print(json.dumps(row),flush=True)
   if row['state']!='complete' or row['total_seconds']>1200 or owned_size(out)>1<<30:raise RuntimeError('Stop after failure/cap; preserve all evidence, no automatic retry')
   if sum(r['wall_seconds']for r in ledger if r['seed']==c['seed'])>300:raise RuntimeError('Per seed300s cap')
 return dict(status='complete',starts=len(ledger),wall_seconds=time.monotonic()-start)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');args=p.parse_args();print(json.dumps(run(args.execute)),flush=True)
