#include "generator.h"
#include "finders.h"
#include <stdlib.h>
#include <stdio.h>
#include <inttypes.h>
int main(void){uint64_t seed;int typ,x,z;Generator*g=calloc(1,sizeof(*g));while(scanf("%"SCNu64" %d %d %d",&seed,&typ,&x,&z)==4){setupGenerator(g,MC_26_50,0);int type=typ?Bastion:Ancient_City;applySeed(g,typ?DIM_NETHER:DIM_OVERWORLD,seed);int cx=floordiv(x,16),cz=floordiv(z,16),ok=1;if(typ){for(int qx=cx*4-1;qx<=cx*4;qx++)for(int qz=cz*4-1;qz<=cz*4;qz++){int id=getNetherBiome(&g->nn,qx,0,qz,NULL);if(!isViableFeatureBiome(MC_26_50,Bastion,id))ok=0;}}else{int id=sampleBiomeNoiseAtBlockY(&g->bn,NULL,cx*4,-27,cz*4,NULL,0);ok=isViableFeatureBiome(MC_26_50,Ancient_City,id);}printf("%d %d\n",!!isViableStructurePos(type,g,x,z,0),ok);}free(g);return 0;}
