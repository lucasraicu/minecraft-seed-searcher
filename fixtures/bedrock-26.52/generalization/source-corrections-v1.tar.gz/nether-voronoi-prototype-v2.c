#include "generator.h"
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
int main(void){uint64_t seed;int x,y,z;Generator*g=calloc(1,sizeof(*g));while(scanf("%"SCNu64" %d %d %d",&seed,&x,&y,&z)==4){setupGenerator(g,MC_26_50,0);applySeed(g,DIM_NETHER,seed);uint64_t st=getStartSalt(seed,getLayerSalt(10));int bx=floordiv(x-2,4),bz=floordiv(z-2,4);float fx=(x-2)-4*bx,fz=(z-2)-4*bz,dist[4];int qx[4],qz[4];for(int k=0;k<4;k++){int dx=k&1,dz=k>>1;qx[k]=bx+dx;qz[k]=bz+dz;uint64_t cs=getChunkSeed(mcStepSeed(st,0),qx[k]*4,qz[k]*4);float a=(((cs>>24)&1023)*(1.f/1024.f)-.5f)*3.6f+dx*4;cs=mcStepSeed(cs,st);float c=(((cs>>24)&1023)*(1.f/1024.f)-.5f)*3.6f+dz*4;a=fx-a;c=fz-c;dist[k]=a*a+c*c;}int k=dist[0]<dist[1]&&dist[0]<dist[2]&&dist[0]<dist[3]?0:dist[1]<dist[0]&&dist[1]<dist[2]&&dist[1]<dist[3]?1:dist[2]<dist[0]&&dist[2]<dist[1]&&dist[2]<dist[3]?2:3;int id=getNetherBiome(&g->nn,qx[k],0,qz[k],NULL);printf("%d %d %d\n",id,qx[k],qz[k]);}free(g);return 0;}
