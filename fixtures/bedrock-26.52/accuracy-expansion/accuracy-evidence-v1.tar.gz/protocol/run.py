import importlib.util,json,hashlib,subprocess,time,re,sys
from pathlib import Path
P=Path(__file__).parent
spec=importlib.util.spec_from_file_location('accuracy_pilot_runner',P/'runner.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

def run(execute=False):
 raw=(P/'frozen.json').read_bytes();manifest=json.loads(raw);sha=hashlib.sha256(raw).hexdigest()
 if sha!=(P/'frozen.sha256').read_text().strip():raise ValueError('Manifest changed')
 if len(manifest['worlds'])!=8 or len({w['seed']for w in manifest['worlds']})!=8:raise ValueError('Eight distinct worlds required')
 for f,h in manifest['files'].items():
  if hashlib.sha256((P/f).read_bytes()).hexdigest()!=h:raise ValueError('Frozen implementation differs')
 for c in manifest['worlds']:
  points=c['points']+[[x+dx,y,z+dz]for x,z,w,h,y in c['tiles']for dz in range(h)for dx in range(w)]
  if not 0<len(points)<=4096 or len({(p[0]//16,p[2]//16)for p in points})>10:raise ValueError('Read/chunk cap')
  if c['structures'] or len(c['tiles'])>4 or c['columns']:raise ValueError('Unsupported pilot request')
 if not execute:return dict(dry_run=True,sha256=sha,worlds=8)
 if subprocess.check_output(['docker','ps','-q'],text=True,timeout=5).strip():raise RuntimeError('Shared BDS resource occupied')
 if subprocess.check_output(['docker','image','inspect',m.IMAGE,'--format','{{.Id}}'],text=True,timeout=5).strip()!=m.IMAGE:raise ValueError('Pinned image differs')
 out=P/'game';out.mkdir(exist_ok=False);ledger=[];start=time.monotonic()
 for i,c in enumerate(manifest['worlds']):
  if time.monotonic()-start>6900 or m.owned_size(out)>3<<30:raise TimeoutError('Campaign safety headroom')
  t=time.monotonic();row=dict(index=i,seed=c['seed'],dimension=c['dimension'],state='starting');ledger.append(row)
  (out/'ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
  try:
   report=m.run_world(c,out/f'world-{i:02}',280,'docker',sha,out,observer_path=P/f'observer-{c["dimension"]}.js')
   ident=report.get('world_identity',{})
   good=(report['status']=='observed' and all(report.get(k)is True for k in ('clean_shutdown','owned_container_removed','save_confirmed')) and ident.get('seed')==c['seed'] and ident.get('dimension')==c['dimension'] and ident.get('api')=='2.10.0' and ident.get('players')==0 and re.search(r'\bVersion: 1\.26\.52\.3(?:\s|$)',(out/f'world-{i:02}/console.log').read_text()))
   if not good:raise RuntimeError('Game observation failed '+str(report.get('error')))
   row.update(state='complete',report_sha256=hashlib.sha256((out/f'world-{i:02}/report.json').read_bytes()).hexdigest())
  except Exception as e:
   row.update(state='failed',error=repr(e));raise
  finally:
   row.update(wall_seconds=time.monotonic()-t,total_seconds=time.monotonic()-start)
   (out/'ledger.json').write_text(json.dumps(ledger,indent=2)+'\n');print(json.dumps(row),flush=True)
  if row['wall_seconds']>300 or row['total_seconds']>7200 or m.owned_size(out)>4<<30:raise RuntimeError('No retry after budget exceeded')
 return dict(status='complete',worlds=8,seconds=time.monotonic()-start)
if __name__=='__main__':print(json.dumps(run('--execute'in sys.argv)),flush=True)
