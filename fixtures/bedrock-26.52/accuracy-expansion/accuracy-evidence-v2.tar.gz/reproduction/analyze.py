from pathlib import Path
import json,math,sys,collections,hashlib
P=Path(__file__).parent;ROOT=Path('/Users/lucasraicu/Downloads/minecraft-seed-searcher');sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
from seed_search.realm.biomes import canonical
f=json.loads((P/'frozen.json').read_bytes());results=[]
alias=json.loads((P.parent.parent/'generalization-validation-20261020/manifest.json').read_text())['aliases']
def name(value):
 value=value.removeprefix('minecraft:');return alias.get(value,value)
for i,c in enumerate(f['worlds']):
 r=json.loads((P/f'game/world-{i:02}/report.json').read_text());expected=c['prediction']['rows'];actual=r['target_result']['rows']
 assert len(expected)==len(actual)
 mismatches=[]
 for e,a in zip(expected,actual):
  assert e['position']==[a['x'],a['y'],a['z']] and a['dimension']==c['dimension']
  if name(e['name'])!=name(a['id']):mismatches.append(dict(position=e['position'],predicted=e['name'],observed=a['id']))
 s=r['world_identity']['worldSpawn'];assert s==r['target_result']['worldSpawn']
 estimate=c['prediction']['estimator']['estimate'];distance=math.hypot(estimate[0]-s['x'],estimate[1]-s['z'])
 results.append(dict(index=i,seed=c['seed'],group=c['group'],dimension=c['dimension'],points=len(actual),
  direct_matches=len(actual)-len(mismatches),mismatches=mismatches,world_spawn=[s['x'],s['z']],world_spawn_y=None,
  raw_spawn_y=s['y'],estimate=estimate,estimate_displacement=distance,report_sha256=hashlib.sha256((P/f'game/world-{i:02}/report.json').read_bytes()).hexdigest()))
report=dict(revision='accuracy-pilot-analysis-v1',worlds=results,total_points=sum(r['points']for r in results),
 matches=sum(r['direct_matches']for r in results),spawn_exact=sum(r['estimate_displacement']==0 for r in results),
 max_spawn_displacement=max(r['estimate_displacement']for r in results),
 limits='Four blind/four targeted worlds; point evidence only, no population accuracy or exact initial-player claim.')
(P/'analysis.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='worlds'}));print([(r['index'],r['direct_matches'],r['points'],r['estimate_displacement'])for r in results])
