from pathlib import Path
import sys,importlib.util,json,hashlib,time
P=Path(__file__).parent;ROOT=Path('/Users/lucasraicu/Downloads/minecraft-seed-searcher');sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'src')]
from predictor_storage_probe import export_world,tree_hashes
spec=importlib.util.spec_from_file_location('accuracy_runner',P/'runner.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
f=json.loads((P/'frozen.json').read_text());c=f['worlds'][7]
source=P/'game/world-07/worlds/world/worlds/spawn_audit';before=tree_hashes(source)
s=(P/'observer-nether.js').read_text().replace("if(DIMENSION==='overworld')for",'for').replace('y:319','y:127').replace('y: 319','y: 127').replace('const b=dim.getBlock({x,y:319,z})','const b=dim.getBlock({x,y:127,z})')
observer=P/'observer-nether-persist.js';observer.write_text(s)
protocol=dict(revision='accuracy-nether-persistence-v1',seed=c['seed'],source_hashes=before,case_sha256=hashlib.sha256(json.dumps(c,sort_keys=True).encode()).hexdigest(),observer_sha256=hashlib.sha256(observer.read_bytes()).hexdigest(),
 objective='One copied-world dirty/restore repair for two missing Nether Data3D records; no new predictor tuning, seeds or relaxed comparison.',caps=dict(world_seconds=280,per_seed_total=300,total_campaign=7200,biome_reads=4096,block_reads=8192))
raw=json.dumps(protocol,sort_keys=True).encode();(P/'nether-persistence-protocol.json').write_bytes(raw)
t=time.monotonic();report=m.run_world(c,P/'game/world-07-persistence',260,'docker',hashlib.sha256(raw).hexdigest(),P/'game',observer_path=observer,copied_world=source)
assert report['status']=='observed' and all(report.get(k)is True for k in ('clean_shutdown','owned_container_removed','save_confirmed')),report.get('error')
assert tree_hashes(source)==before
out=P/'game/world-07-persistence';e=export_world(out/'worlds/world/worlds/spawn_audit',out/'report.json',P/'export-07-persistence.json',dimension_aware=True)
assert all(row['restored'] for row in report['target_result']['mutations'])
print(json.dumps(dict(seed=c['seed'],status='complete',seconds=time.monotonic()-t,records=len(e['records']),source_unchanged=True,mutations=report['target_result']['mutations'])))
