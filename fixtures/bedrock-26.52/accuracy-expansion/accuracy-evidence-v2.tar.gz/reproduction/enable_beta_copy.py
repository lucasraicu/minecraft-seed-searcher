from pathlib import Path
import struct
import amulet_nbt
p=Path('/copy/level.dat');raw=p.read_bytes();tag=amulet_nbt.load(raw[8:],compressed=False,little_endian=True)
e=tag.compound['experiments'];e['gametest']=amulet_nbt.ByteTag(1);e['experiments_ever_used']=amulet_nbt.ByteTag(1);e['saved_with_toggled_experiments']=amulet_nbt.ByteTag(1)
data=tag.save_to(compressed=False,little_endian=True);p.write_bytes(raw[:4]+struct.pack('<I',len(data))+data)
print('Enabled Beta APIs on owned copy only')
