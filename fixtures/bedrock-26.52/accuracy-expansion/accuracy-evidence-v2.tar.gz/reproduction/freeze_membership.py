from pathlib import Path
import sys,json,hashlib,collections,shutil
P=Path(__file__).parent;BASE=P.parent.parent/'generalization-validation-20261020';ROOT=Path('/Users/lucasraicu/Downloads/minecraft-seed-searcher');sys.path[:0]=[str(ROOT/'src'),str(ROOT/'scripts')]
from seed_search.catalog.structure_verification import TYPES
from predictor_storage_probe import tree_hashes
results=json.loads((BASE/'results.json').read_text());manifest=json.loads((BASE/'manifest.json').read_text())
worlds={w['seed']:w for w in manifest['worlds']};selected=[]
for typ in TYPES:
 candidates=[r for r in results['structure_rows']if r['structure_type']==typ and r['cohort']=='blind' and r['reported'] is not None and max(abs(v)for v in r['reported'])<=5000]
 if typ=='abandoned_camp':
  candidates=[r for r in results['structure_rows']if r['structure_type']==typ and r['cohort']=='blind' and r['predicted'] is not None]
 assert candidates,typ
 # Choose recorded reference from original frozen audit; no new outcome tuning.
 r=min(candidates,key=lambda r:(worlds[r['seed']]['index'],r['disposition']!='retained',r['case_id']))
 x,z=r['predicted'] if r['reported'] is None else r['reported']
 heights=([-51,-35,-19]if typ=='ancient_city' else [-32,-16,0,16]if typ=='trial_chamber' else [0,16,32,48]if typ in ('stronghold','mineshaft') else [32,48,64,80]if r['dimension']=='nether' else [48,64,80,96])
 points=[[x+dx,y,z+dz]for dx,dz in [(0,0),(4,4),(-4,-4)]for y in heights]
 selected.append(dict(structure_type=typ,seed=r['seed'],dimension=r['dimension'],reference=r['reported'],raw_start=r['predicted'],source_case_id=r['case_id'],points=points))
by=collections.defaultdict(list)
for s in selected:by[(s['seed'],s['dimension'])].append(s)
cases=[]
for(seed,dim),types in by.items():
 batch=[]
 def flush():
  if not batch:return
  wi=worlds[seed]['index'];d=BASE/f'game/world-{wi:02}'
  report=json.loads((d/'report.json').read_text());source=Path(report.get('work_directory',str(d/'worlds/world')))/'worlds/spawn_audit'
  points=list(dict.fromkeys(tuple(p)for t in batch for p in t['points']))
  assert len(points)<=64 and len({(p[0]//16,p[2]//16)for p in points})<=10
  cases.append(dict(seed=seed,dimension=dim,points=[list(p)for p in points],columns=[],structures=[],types=list(batch),
   source_world=str(source),source_hashes=tree_hashes(source),prediction=dict(seed=seed,role='Copied-world positive point-type verifier only; not predicted-instance association or census')))
 for t in types:
  candidate=batch+[t];pts={tuple(p)for tt in candidate for p in tt['points']}
  if len(pts)>64 or len({(p[0]//16,p[2]//16)for p in pts})>10:flush();batch=[]
  batch.append(t)
 flush()
for dim in ('overworld','nether'):
 s=(BASE/f'membership-observer-{dim}-load400.js').read_text()
 (P/f'type-observer-{dim}.js').write_text(s)
shutil.copyfile(BASE/'enable_beta_copy.py',P/'enable_beta_copy.py')
files={f:hashlib.sha256((P/f).read_bytes()).hexdigest()for f in ['type-observer-overworld.js','type-observer-nether.js','enable_beta_copy.py']}
value=dict(revision='accuracy-type-membership-pilot-v1',cases=cases,files=files,
 scope='21type point witnesses on copied worlds with Beta APIs. No empty-point absence inference, physical census, default-settings certification, or clustering.')
raw=json.dumps(value,sort_keys=True,separators=(',',':')).encode();(P/'membership-frozen.json').write_bytes(raw);(P/'membership-frozen.sha256').write_text(hashlib.sha256(raw).hexdigest()+'\n')
print(json.dumps(dict(cases=len(cases),types=len(selected),points=sum(len(c['points'])for c in cases),source_seeds=sorted({c['seed']for c in cases}),hash=hashlib.sha256(raw).hexdigest())))
