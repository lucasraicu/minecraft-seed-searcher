from pathlib import Path
import sys,json,hashlib,time,subprocess,uuid,collections
P=Path(__file__).parent;ROOT=Path('/Users/lucasraicu/Downloads/minecraft-seed-searcher');sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'src')]
from predictor_targeted_bds import run_world,IMAGE,owned_size
from predictor_storage_probe import tree_hashes
raw=(P/'membership-frozen.json').read_bytes();f=json.loads(raw);sha=hashlib.sha256(raw).hexdigest()
assert sha==(P/'membership-frozen.sha256').read_text().strip()
for name,h in f['files'].items():assert hashlib.sha256((P/name).read_bytes()).hexdigest()==h
for c in f['cases']:assert tree_hashes(c['source_world'])==c['source_hashes']
if '--execute'not in sys.argv:print(json.dumps(dict(dry_run=True,cases=len(f['cases']),points=sum(len(c['points'])for c in f['cases']))));sys.exit(0)
assert not subprocess.check_output(['docker','ps','-q'],text=True,timeout=5).strip()
out=P/'membership-game';out.mkdir(exist_ok=False);ledger=[];charges=collections.Counter();start=time.monotonic()
def enable(target):
 subprocess.run(['docker','run','--rm','--pull=never','--read-only','--network','none','--name','codex-accuracy-beta-'+uuid.uuid4().hex[:10],
  '--cpus','1','--memory','256m','--pids-limit','32','--mount',f'type=bind,src={target},dst=/copy',
  '--mount',f'type=bind,src={P/"enable_beta_copy.py"},dst=/enable_beta_copy.py,readonly',
  '--entrypoint','/opt/reader/bin/python',IMAGE,'/enable_beta_copy.py'],capture_output=True,text=True,check=True,timeout=30)
for i,c in enumerate(f['cases']):
 if charges[c['seed']]>150 or time.monotonic()-start>1800 or owned_size(P)>3<<30:raise RuntimeError('Resource headroom')
 t=time.monotonic();row=dict(index=i,seed=c['seed'],dimension=c['dimension'],state='starting');ledger.append(row)
 (out/'ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
 try:
  r=run_world(c,out/f'case-{i:02}',90,'docker',sha,out,observer_path=P/f'type-observer-{c["dimension"]}.js',copied_world=c['source_world'],script_api='2.11.0-beta',prepare_copy=enable)
  assert r['status']=='observed' and all(r.get(k)is True for k in ('clean_shutdown','owned_container_removed','save_confirmed')),r.get('error')
  assert r['world_identity']['membershipAvailable'] is True and r['world_identity']['seed']==c['seed'] and tree_hashes(c['source_world'])==c['source_hashes']
  row['state']='complete'
 except Exception as e:row.update(state='failed',error=repr(e));raise
 finally:
  row['seconds']=time.monotonic()-t;charges[c['seed']]+=row['seconds'];row['seed_seconds']=charges[c['seed']]
  (out/'ledger.json').write_text(json.dumps(ledger,indent=2)+'\n');print(json.dumps(row),flush=True)
 if charges[c['seed']]>300:raise RuntimeError('Per seed cap')
print(json.dumps(dict(status='complete',cases=len(ledger),seconds=time.monotonic()-start)))
