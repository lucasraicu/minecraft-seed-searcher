from pathlib import Path
import sys,json,hashlib,time,subprocess,uuid
P=Path(__file__).parent;ROOT=Path('/Users/lucasraicu/Downloads/minecraft-seed-searcher');sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'src')]
from predictor_targeted_bds import run_world,IMAGE
from predictor_storage_probe import tree_hashes
source=P.parent.parent/'generalization-validation-20261020/game/world-00/worlds/world/worlds/spawn_audit'
cases=[dict(name='jungle',points=[[x,y,z]for x,z in [(-1736,2824),(-1732,2828),(-1740,2820),(-1740,2828)]for y in range(64,77)]),
 dict(name='outpost',points=[[x,y,z]for x in [152,160,168,176]for z in[344,352,360,368]for y in[64,76,88]]),
 dict(name='camp',points=[[x,y,z]for x,z in[(221,212),(224,208),(220,208),(228,212)]for y in range(62,78)])]
for c in cases:c.update(seed='-4604339825072288470',dimension='overworld',columns=[],structures=[],prediction=dict(seed='-4604339825072288470',role='Bounded point-type followup after sparse misses; no absence/census claim'))
raw=json.dumps(dict(revision='type-point-refinement-v1',source_hashes=tree_hashes(source),cases=cases),sort_keys=True).encode();(P/'type-point-refinement-frozen.json').write_bytes(raw)
out=P/'type-point-refinement';out.mkdir(exist_ok=False);start=time.monotonic();ledger=[]
def enable(target):
 subprocess.run(['docker','run','--rm','--pull=never','--read-only','--network','none','--name','codex-types-beta-'+uuid.uuid4().hex[:10],'--cpus','1','--memory','256m','--pids-limit','32','--mount',f'type=bind,src={target},dst=/copy','--mount',f'type=bind,src={P/"enable_beta_copy.py"},dst=/enable_beta_copy.py,readonly','--entrypoint','/opt/reader/bin/python',IMAGE,'/enable_beta_copy.py'],capture_output=True,text=True,check=True,timeout=30)
for c in cases:
 assert len(c['points'])<=64 and len({(p[0]//16,p[2]//16)for p in c['points']})<=10
 if time.monotonic()-start>100:raise TimeoutError('Per seed cumulative headroom')
 t=time.monotonic();r=run_world(c,out/c['name'],80,'docker',hashlib.sha256(raw).hexdigest(),out,observer_path=P/'type-observer-overworld.js',copied_world=source,script_api='2.11.0-beta',prepare_copy=enable)
 assert r['status']=='observed' and all(r.get(k)is True for k in ('save_confirmed','clean_shutdown','owned_container_removed')),r.get('error')
 from collections import Counter
 types=Counter(t for row in r['target_result']['rows']for t in row['structures'])
 ledger.append(dict(name=c['name'],seconds=time.monotonic()-t,membership=dict(types)));(out/'ledger.json').write_text(json.dumps(ledger,indent=2)+'\n');print(json.dumps(ledger[-1]),flush=True)
assert tree_hashes(source)==json.loads(raw)['source_hashes']
