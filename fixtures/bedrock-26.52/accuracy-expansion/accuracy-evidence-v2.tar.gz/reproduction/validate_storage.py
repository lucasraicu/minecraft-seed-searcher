from pathlib import Path
import json,sys,hashlib,collections
P=Path(__file__).parent;ROOT=Path('/Users/lucasraicu/Downloads/minecraft-seed-searcher');sys.path[:0]=[str(ROOT/'src')]
from seed_search.catalog.biome_provider import StoredBiomeProvider
from seed_search.catalog.models import identity
from seed_search.realm.bedrock_biome_storage import decode_data3d
f=json.loads((P/'frozen.json').read_text());rows=[];associations=collections.defaultdict(set);summaries=[]
for i,c in enumerate(f['worlds']):
 e=json.loads((P/f'export-{i:02}.json').read_text());r=json.loads((P/f'game/world-{i:02}/report.json').read_text())
 assert e['world_identity']['seed']==c['seed']
 spawn=e['world_identity']['world_spawn'];observed=r['world_identity']['worldSpawn']
 assert [spawn['SpawnX'],spawn['SpawnZ']]==[observed['x'],observed['z']]
 ctx=dict(identity=identity(c['seed'],model_id='26.50',native_sha256='19a4b81e2ed97ca1d5033db789225a0ad421cc7de2032d9e20be510cde59965e',source_sha256=c['prediction']['source_sha256']),
  dimension=c['dimension'],provider='bds_saved_runtime_v3',observed_build='1.26.52.3',evidence_sha256=hashlib.sha256((P/f'export-{i:02}.json').read_bytes()).hexdigest())
 records=[dict(chunk_x=v['cx'],chunk_z=v['cz'],payload=bytes.fromhex(v['data']))for v in e['records'] if v['dimension']==c['dimension']]
 provider=StoredBiomeProvider(ctx,records)
 local=[]
 for a in r['target_result']['rows']:
  s=provider.sample(a['x'],a['y'],a['z']);row=dict(index=i,seed=c['seed'],dimension=c['dimension'],coordinate=s['coordinate'],stored_id=s['raw_id'],api_name=a['id'],status=s['status'])
  local.append(row);rows.append(row)
  if s['raw_id'] is not None:associations[(c['dimension'],s['raw_id'])].add(a['id'])
 ceilings=[]
 for v in records:
  d=decode_data3d(v['payload'],floor_section=-4 if c['dimension']=='overworld' else 0,max_sections=25 if c['dimension']=='overworld' else 8)
  ceilings.append(max(s.section_y*16+15 for s in d.sections if s.kind!='unknown'))
 summaries.append(dict(index=i,points=len(local),stored=sum(v['stored_id']is not None for v in local),unknown=sum(v['stored_id']is None for v in local),ceilings=ceilings,world_spawn_matches_level_dat=True))
# Associations are measured consistency checks, NOT guessed Bedrock/native ID equivalence.
conflicts={str(k):sorted(v)for k,v in associations.items()if len(v)>1}
report=dict(revision='accuracy-storage-validation-v1',worlds=summaries,points=len(rows),stored=sum(r['stored_id']is not None for r in rows),unknown=sum(r['stored_id']is None for r in rows),
 id_name_association_conflicts=conflicts,associations=[dict(dimension=d,stored_id=i,api_names=sorted(v))for(d,i),v in sorted(associations.items())],
 scope='Per-record runtime decoding against API string consistency. ID/name associations measured here are not independent universal registry proof; unknown records retained.')
(P/'storage-rows.json').write_text(json.dumps(rows,separators=(',',':'))+'\n');(P/'storage-analysis.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
assert not conflicts
