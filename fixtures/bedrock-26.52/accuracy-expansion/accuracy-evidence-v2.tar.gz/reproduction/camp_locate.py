from pathlib import Path
import json,sys,time,hashlib
P=Path(__file__).parent;ROOT=Path('/Users/lucasraicu/Downloads/minecraft-seed-searcher');sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'src')]
from predictor_targeted_bds import run_world
from predictor_storage_probe import tree_hashes
base=P.parent.parent/'generalization-validation-20261020';source=base/'game/world-00/worlds/world/worlds/spawn_audit'
case=dict(seed='-4604339825072288470',dimension='overworld',points=[[224,64,208]],columns=[],structures=[dict(feature='structure.abandoned_camp',command_id=name,point=[224,208])for name in ('abandoned_camp','abandoned_camp_taiga','abandoned_camp_forest')],prediction=dict(seed='-4604339825072288470',role='Source-defined structure-ID command discriminator, not a native prediction or census'))
protocol=dict(revision='camp-command-discriminator-v1',case=case,source_hashes=tree_hashes(source),structure_set_sha256=hashlib.sha256((P/'camp-structure-set.json').read_bytes()).hexdigest(),
 hypothesis='Source pack defines abandoned_camp as a structure set and biome-specific jigsaw structure identifiers. Test exact identifiers without assuming registration failure.',seconds=180)
raw=json.dumps(protocol,sort_keys=True).encode();(P/'camp-command-protocol.json').write_bytes(raw)
t=time.monotonic();report=run_world(case,P/'camp-command-game',150,'docker',hashlib.sha256(raw).hexdigest(),P,observer_path=P.parent/'b-observer-overworld.js',copied_world=source)
assert report['status']=='observed' and all(report.get(k)is True for k in('save_confirmed','clean_shutdown','owned_container_removed')),report.get('error')
assert tree_hashes(source)==protocol['source_hashes']
print(json.dumps(dict(status='complete',seconds=time.monotonic()-t,queries=report['queries'])))
