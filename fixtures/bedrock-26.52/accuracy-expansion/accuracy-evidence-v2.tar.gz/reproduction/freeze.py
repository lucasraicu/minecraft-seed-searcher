from pathlib import Path
import sys,json,hashlib,subprocess,time
P=Path(__file__).parent;BASE=P.parent;R=BASE/'source-runtime'
sys.path.insert(0,str(R/'src'))
from seed_search.backend import Backend,native_runtime,biome_name
from seed_search.realm.native_identity import native_source_fingerprint
native_runtime();source=native_source_fingerprint();assert source=='72694b1420170b4582358eef577cc252c11e138daec817bbf97d4af68e645c1a'
blind=[str(int.from_bytes(hashlib.sha256(('accuracy-pilot-v1/'+str(i)).encode()).digest()[:8],'little',signed=True)) for i in range(4)]
seeds=blind+['7370389603366252746','219044158440418215','-3509659830737203357','4027938806717471239']
# Four blind seeds frozen independently, four targeted old cases. Signed extremes
# already in old108 spawn controls; don't relabel replay as fresh held-out evidence.
worlds=[];start=time.monotonic();scalar_checks=0
for i,seed in enumerate(seeds):
 dim='overworld' if i in (0,2,4,6) else 'nether';dimension=0 if dim=='overworld' else -1
 x,z=((224,-320) if i==4 else (-32,-32) if i%2 else (0,0))
 heights=[-64,-49,-48,-33,-32,-17,-16,-1,0,15,16,63,79,80,95,96,127,128,255,319] if dim=='overworld' else [0,15,16,31,32,63,64,95,96,111,112,127]
 tileheights=[63,95] if dim=='overworld' else [16,112]
 tiles=[[x,z,32,32,y] for y in tileheights];points=[[x+1,y,z+1] for y in heights if y not in tileheights]
 expanded=points+[[tx+dx,y,tz+dz]for tx,tz,w,h,y in tiles for dz in range(h)for dx in range(w)]
 with Backend(seed)as b:
  ids=list(map(int,b.biome_points(expanded,dimension=dimension)))
  for j,point in enumerate(expanded[len(points):len(points)+1024]):
   assert b.biome(*point,dimension=dimension)==ids[len(points)+j];scalar_checks+=1
  oldpoints={tuple(p) for p in expanded};assert len(oldpoints)==len(expanded)
 estimate=json.loads(subprocess.check_output([str(BASE/'current-spawn-replay')],input=seed+'\n',text=True,timeout=5))
 case=dict(seed=seed,dimension=dim,group='blind' if i<4 else 'targeted',points=points,tiles=tiles,columns=[],structures=[],
  prediction=dict(seed=seed,source_sha256=source,estimator=estimate,
  rows=[dict(position=p,raw_id=bid,name=biome_name(bid))for p,bid in zip(expanded,ids)]))
 worlds.append(case)
 if time.monotonic()-start>60:raise TimeoutError('Native tile pilot60s cap')
files=['runner.py','observer-overworld.js','observer-nether.js']
manifest=dict(revision='accuracy-expansion-pilot-v1',worlds=worlds,
  files={f:hashlib.sha256((P/f).read_bytes()).hexdigest()for f in files},
  limits=dict(max_worlds=8,seconds_per_world=300,total_seconds=7200,max_bytes=4<<30,biome_reads_per_world=4096,block_reads_per_world=8192,chunks=10),
  native_controls=dict(scalar_checks=scalar_checks,vector_points=sum(len(w['prediction']['rows'])for w in worlds),seconds=time.monotonic()-start),
  interpretation='Default stable API, worldspawnXZ and exact biome point observations. No initial-player or physical census oracle.')
raw=json.dumps(manifest,sort_keys=True,separators=(',',':')).encode();(P/'frozen.json').write_bytes(raw);(P/'frozen.sha256').write_text(hashlib.sha256(raw).hexdigest()+'\n');print(json.dumps(dict(seeds=seeds,native=manifest['native_controls'],sha256=hashlib.sha256(raw).hexdigest())))
